import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Main extends JFrame {
    private JPanel panel1;
    private JTextField streetText;
    private JTextField codeText;
    private JTextField stateText;
    private JTextField cityText;
    private JButton crearButton;
    private JTextArea mostrarResultados;
    private JTextArea EliText;
    private JButton eliminarButton;
    private JTextField destinatarioTextField;
    private JTextField estadoTextField;
    private JTextField noSeguimientoTextField;
    private JTextField ciudadTextField;
    private JTextField codigoPostalTextField;
    private JTextArea BusText;
    private JButton buscarButton;

    private List<Package> packages = new ArrayList<>();

    public static void main(String[] args){

    }
    public Main() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setContentPane(panel1);
        pack();
        setVisible(true);

        crearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Address sender = new Address(streetText.getText(), cityText.getText(), stateText.getText(), codeText.getText());
                Address recipient = new Address("", ciudadTextField.getText(), estadoTextField.getText(), codigoPostalTextField.getText());
                Package pkg = new Package("AS" + String.format("%03d", packages.size() + 1), sender, recipient, null);
                packages.add(pkg);
                mostrarResultados.append("Paquete creado: " + pkg.toString() + "\n");
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String trackingNumber = EliText.getText().trim();
                boolean removed = packages.removeIf(pkg -> pkg.getTrackingNumber().equals(trackingNumber));
                if (removed) {
                    mostrarResultados.append("Paquete eliminado: " + trackingNumber + "\n");
                } else {
                    mostrarResultados.append("Paquete no encontrado: " + trackingNumber + "\n");
                }
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String recipientAddress = destinatarioTextField.getText().trim();
                List<Package> searchResults = new ArrayList<>();
                for (Package pkg : packages) {
                    if (pkg.getRecipientAddress().getCity().equals(recipientAddress)) {
                        searchResults.add(pkg);
                    }
                }
                mostrarResultados.append("Resultados de búsqueda por destinatario: " + recipientAddress + "\n");
                if (searchResults.isEmpty()) {
                    mostrarResultados.append("No se encontraron paquetes.\n");
                } else {
                    for (Package pkg : searchResults) {
                        mostrarResultados.append(pkg.toString() + "\n");
                    }
                }
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String trackingNumber = noSeguimientoTextField.getText().trim();
                int index = binarySearch(packages, trackingNumber);
                mostrarResultados.append("Resultados de búsqueda por número de seguimiento: " + trackingNumber + "\n");
                if (index == -1) {
                    mostrarResultados.append("No se encontró el paquete.\n");
                } else {
                    mostrarResultados.append(packages.get(index).toString() + "\n");
                }
            }
        });
    }

    private int binarySearch(List<Package> packages, String trackingNumber) {
        int low = 0;
        int high = packages.size() - 1;
        while (low <= high) {
            int mid = ( mid = (low + high) / 2);
            String midTrackingNumber = packages.get(mid).getTrackingNumber();
            int compareResult = trackingNumber.compareTo(midTrackingNumber);
            if (compareResult == 0) {
                return mid;
            } else if (compareResult < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return -1;
    }
}