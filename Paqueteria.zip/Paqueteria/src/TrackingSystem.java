import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TrackingSystem {

    private List<Package> packages;

    public TrackingSystem() {
        packages = new ArrayList<>();
    }

    public void addPackage(Package pkg) {
        packages.add(pkg);
    }

    public boolean removePackage(String trackingNumber) {
        for (Package pkg : packages) {
            if (pkg.getTrackingNumber().equals(trackingNumber)) {
                packages.remove(pkg);
                return true;
            }
        }
        return false;
    }

    public Package searchByRecipientAddress(String recipientAddress) {
        for (Package pkg : packages) {
            if (pkg.getRecipientAddress().toString().equals(recipientAddress)) {
                return pkg;
            }
        }
        return null;
    }

    public Package searchByTrackingNumber(String trackingNumber) {
        Collections.sort(packages, new PackageComparator());
        int index = Collections.binarySearch(packages, new Package(trackingNumber, null, null, null), new PackageComparator());
        if (index >= 0) {
            return packages.get(index);
        }
        return null;
    }

    public List<Package> searchByCity(String city) {
        List<Package> result = new ArrayList<>();
        for (Package pkg : packages) {
            if (pkg.getRecipientAddress().getCity().equals(city)) {
                result.add(pkg);
            }
        }
        return result;
    }

    private class PackageComparator implements java.util.Comparator<Package> {

        @Override
        public int compare(Package p1, Package p2) {
            return p1.getTrackingNumber().compareTo(p2.getTrackingNumber());
        }
        Address senderAddress1 = new Address("123 Main St", "Anytown", "CA", "12345");
        Address recipientAddress1 = new Address("456 Oak St", "Anycity", "NY", "67890");
        Package package1 = new Package("AS001", senderAddress1, recipientAddress1, LocalDate.of(2023, 5, 20));

        Address senderAddress2 = new Address("789 Maple Ave", "Anyville", "FL", "45678");
        Address recipientAddress2 = new Address("321 Elm St", "Anystate", "TX", "90123");
        Package package2 = new Package("AS002", senderAddress2, recipientAddress2, LocalDate.of(2023, 5, 22));

        Address senderAddress3 = new Address("234 Pine St", "Anytown", "WA", "34567");
        Address recipientAddress3 = new Address("567 Cedar Ave", "Anycity", "PA", "89012");
        Package package3 = new Package("AS003", senderAddress3, recipientAddress3, LocalDate.of(2023, 5, 23));

        Address senderAddress4 = new Address("890 Oak St", "Anyville", "MA", "56789");
        Address recipientAddress4 = new Address("123 Maple Ave", "Anystate", "VA", "23456");
        Package package4 = new Package("AS004", senderAddress4, recipientAddress4, LocalDate.of(2023, 5, 25));

        Address senderAddress5 = new Address("456 Cedar Ave", "Anytown", "IL", "67890");
        Address recipientAddress5 = new Address("789 Pine St", "Anycity", "NC", "12345");
        Package package5 = new Package("AS005", senderAddress5, recipientAddress5, LocalDate.of(2023, 5, 26));

        Address senderAddress6 = new Address("901 Elm St", "Anyville", "OH", "23443");
        Address recipientAddress6 = new Address("789 Pine St", "Anycity", "NC", "12345");
        Package package6 = new Package("AS006", senderAddress6, recipientAddress6, LocalDate.of(2023, 5, 26));
    }
}
